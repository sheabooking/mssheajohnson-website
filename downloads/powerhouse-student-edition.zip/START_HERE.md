# Powerhouse Student Edition: Start Here

Welcome! This is a free study partner for Claude. It remembers where you left off, keeps your course files in order, helps you build a study plan that fits how your course works, and helps you learn the material yourself.

**A gift from Shea Johnson · Powerhouse Entrepreneur Series · mssheajohnson.com**
Version 1 · November 2026

## What you need
- The Claude desktop app (Mac or Windows) and a Claude account. The desktop app is the easiest way to use it.
- The file `powerhouse-student-edition.zip` (it came with this note). **Don't unzip it.** Claude takes it as is.
- Nothing technical. No Terminal, no code.

## Three steps
1. **Add the skill.** In the Claude desktop app, open **Settings**, find **Skills** (it may be under "Capabilities"), choose **Upload skill**, and pick `powerhouse-student-edition.zip`. Make sure it's switched on.
2. **Make a Study folder.** Create a folder on your computer called "Study." When you start a chat, give Claude access to that folder if your app offers it. (No folder? It still works. It keeps your study log in the chat and hands it to you to save at the end of each session.)
3. **Say "let's study."** Start a new chat and type: **let's study**. Your Study Buddy asks you six short questions, one at a time, and sets everything up for you.

The names of buttons can change as Claude updates its app. If you can't find Skills, search Claude's help pages for "upload a skill."

## How to talk to it
- "Let's study" starts a session.
- "Quiz me" asks you questions from your own course files.
- Hand it a file (like your syllabus) and it files it and pulls out your due dates.
- Tell it how you really feel today. It sets the pace from there.

## The honest-help promise
It's built to help you learn the material, not to write work for you to turn in. It explains, quizzes you, brainstorms and reviews your own work. It stays out of tests and quizzes while they're open. **Your school's rules come first.** Tell it your school's AI rule at setup and it follows that rule. You're responsible for following your school's rules on AI.

## Good to know
- Shea Johnson never sees anything you share. Your log is a file on your own computer, and your chats stay in your own Claude account.
- Don't share passwords, student ID numbers, financial aid, medical or disability details with it.
- Study help only. Not academic advising, tutoring for credit or counseling. If you're ever in crisis, in the US call or text **988** any time; outside the US, call your local emergency number.

*Independent. Not affiliated with or sponsored by Anthropic, and not affiliated with any school. Claude is a product of Anthropic.*
